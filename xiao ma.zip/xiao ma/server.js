const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.static(path.join(__dirname)));
app.use(express.json());

// ─── Game State ───────────────────────────────────────────────────────────────
const rooms = new Map();   // roomCode -> RoomState
const clients = new Map(); // ws -> { playerId, roomCode, name }

function generateCode() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

// ─── Mahjong Tile Engine ──────────────────────────────────────────────────────
const SUITS = ['m','p','s']; // 萬筒索
const HONORS = ['東','南','西','北','中','發','白'];

function buildDeck() {
  const deck = [];
  for (const s of SUITS) {
    for (let n = 1; n <= 9; n++) {
      for (let k = 0; k < 4; k++) deck.push(`${n}${s}`);
    }
  }
  for (const h of HONORS) {
    for (let k = 0; k < 4; k++) deck.push(h);
  }
  return deck;
}

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function dealHands(deck, mode) {
  const count = mode === '2p' ? 2 : 4;
  const hands = [];
  for (let i = 0; i < count; i++) {
    hands.push(deck.splice(0, 13));
  }
  return hands;
}

// Check if tiles form valid groups (simplified win check)
function canWin(tiles) {
  const sorted = [...tiles].sort();
  return checkWin(sorted);
}

function checkWin(tiles) {
  if (tiles.length === 0) return true;
  if (tiles.length % 3 !== 2 && tiles.length % 3 !== 0) return false;
  // Try pair first if length % 3 === 2
  if (tiles.length % 3 === 2) {
    for (let i = 0; i < tiles.length - 1; i++) {
      if (tiles[i] === tiles[i + 1]) {
        const rest = [...tiles];
        rest.splice(i, 2);
        if (checkGroups(rest)) return true;
      }
    }
    return false;
  }
  return checkGroups(tiles);
}

function checkGroups(tiles) {
  if (tiles.length === 0) return true;
  const t = tiles[0];
  const rest = tiles.slice(1);
  // Try triplet
  const idx2 = rest.indexOf(t);
  if (idx2 !== -1) {
    const rest2 = [...rest];
    rest2.splice(idx2, 1);
    const idx3 = rest2.indexOf(t);
    if (idx3 !== -1) {
      const rest3 = [...rest2];
      rest3.splice(idx3, 1);
      if (checkGroups(rest3)) return true;
    }
  }
  // Try sequence (only for suit tiles)
  const suit = t.slice(-1);
  const num = parseInt(t);
  if (!isNaN(num) && SUITS.includes(suit)) {
    const t2 = `${num+1}${suit}`, t3 = `${num+2}${suit}`;
    const i2 = rest.indexOf(t2), i3 = rest.indexOf(t3);
    if (i2 !== -1 && i3 !== -1) {
      const r = [...rest];
      r.splice(r.indexOf(t2), 1);
      r.splice(r.indexOf(t3), 1);
      if (checkGroups(r)) return true;
    }
  }
  return false;
}

function canPong(hand, tile) {
  return hand.filter(t => t === tile).length >= 2;
}

function canChow(hand, tile) {
  const suit = tile.slice(-1);
  const num = parseInt(tile);
  if (isNaN(num) || !SUITS.includes(suit)) return false;
  const check = (a, b) => hand.includes(`${a}${suit}`) && hand.includes(`${b}${suit}`);
  return check(num-2,num-1) || check(num-1,num+1) || check(num+1,num+2);
}

// ─── Room Logic ───────────────────────────────────────────────────────────────
class MahjongRoom {
  constructor(code, mode, hostId, hostName) {
    this.code = code;
    this.mode = mode; // '2p' or '4p'
    this.maxPlayers = mode === '2p' ? 2 : 4;
    this.players = [{ id: hostId, name: hostName, hand: [], melds: [], score: 1000, ws: null, ready: false }];
    this.deck = [];
    this.discard = [];
    this.currentTurn = 0;
    this.phase = 'waiting'; // waiting | playing | ended
    this.lastDiscard = null;
    this.lastDiscardPlayer = -1;
    this.drawCount = 0;
  }

  addPlayer(id, name, ws) {
    if (this.players.length >= this.maxPlayers) return false;
    this.players.push({ id, name, hand: [], melds: [], score: 1000, ws, ready: false });
    return true;
  }

  setWs(id, ws) {
    const p = this.players.find(p => p.id === id);
    if (p) p.ws = ws;
  }

  startGame() {
    this.deck = shuffle(buildDeck());
    const hands = dealHands(this.deck, this.mode);
    this.players.forEach((p, i) => {
      p.hand = hands[i].sort();
      p.melds = [];
    });
    this.currentTurn = 0;
    this.phase = 'playing';
    this.discard = [];
    this.lastDiscard = null;
    this.drawCount = 0;
    // Give first player an extra tile
    this.drawTile(0);
    this.broadcast({ type: 'game_start', players: this.players.map(p => ({ id: p.id, name: p.name, score: p.score, meldCount: p.melds.length })) });
    this.sendHands();
    this.broadcastState();
  }

  drawTile(playerIdx) {
    if (this.deck.length === 0) {
      this.endGame('draw');
      return null;
    }
    const tile = this.deck.pop();
    this.players[playerIdx].hand.push(tile);
    this.players[playerIdx].hand.sort();
    this.drawCount++;
    return tile;
  }

  discard_tile(playerIdx, tile) {
    const p = this.players[playerIdx];
    const idx = p.hand.indexOf(tile);
    if (idx === -1) return false;
    p.hand.splice(idx, 1);
    this.discard.push(tile);
    this.lastDiscard = tile;
    this.lastDiscardPlayer = playerIdx;
    // Check if anyone can pong/chow/win
    const actions = this.checkActions(tile, playerIdx);
    if (actions.length > 0) {
      this.phase = 'action';
      this.broadcast({ type: 'action_prompt', tile, actions, from: playerIdx });
      // Auto-pass after 5s (simplified)
      this.actionTimer = setTimeout(() => {
        if (this.phase === 'action') {
          this.nextTurn();
        }
      }, 8000);
    } else {
      this.nextTurn();
    }
    this.broadcastState();
    return true;
  }

  checkActions(tile, fromPlayer) {
    const actions = [];
    this.players.forEach((p, i) => {
      if (i === fromPlayer) return;
      const canW = canWin([...p.hand, tile]);
      const canP = canPong(p.hand, tile);
      const isNext = (i === (fromPlayer + 1) % this.players.length);
      const canC = isNext && canChow(p.hand, tile);
      if (canW || canP || canC) {
        actions.push({ playerIdx: i, canWin: canW, canPong: canP, canChow: canC });
      }
    });
    return actions;
  }

  handleAction(playerIdx, action, tiles) {
    clearTimeout(this.actionTimer);
    const p = this.players[playerIdx];
    const tile = this.lastDiscard;
    if (!tile) return;

    if (action === 'win') {
      p.hand.push(tile);
      this.discard.pop();
      this.endGame('win', playerIdx);
    } else if (action === 'pong') {
      p.hand.push(tile);
      p.hand.splice(p.hand.indexOf(tile), 1);
      p.hand.splice(p.hand.indexOf(tile), 1);
      p.hand.splice(p.hand.indexOf(tile), 1);
      p.melds.push([tile, tile, tile]);
      this.discard.pop();
      this.currentTurn = playerIdx;
      this.phase = 'playing';
      this.broadcast({ type: 'meld', playerIdx, meld: [tile,tile,tile], meldType:'pong' });
      this.broadcastState();
    } else if (action === 'chow') {
      p.hand.push(tile);
      tiles.forEach(t => p.hand.splice(p.hand.indexOf(t), 1));
      p.melds.push(tiles);
      this.discard.pop();
      this.currentTurn = playerIdx;
      this.phase = 'playing';
      this.broadcast({ type: 'meld', playerIdx, meld: tiles, meldType:'chow' });
      this.broadcastState();
    } else {
      this.nextTurn();
    }
  }

  nextTurn() {
    this.phase = 'playing';
    this.currentTurn = (this.currentTurn + 1) % this.players.length;
    const drawn = this.drawTile(this.currentTurn);
    if (!drawn) return;
    const p = this.players[this.currentTurn];
    if (p.ws) {
      p.ws.send(JSON.stringify({ type: 'your_turn', hand: p.hand, drawn }));
    }
    this.broadcast({ type: 'turn_change', currentTurn: this.currentTurn, deckLeft: this.deck.length });
  }

  endGame(reason, winnerIdx) {
    this.phase = 'ended';
    const winner = winnerIdx !== undefined ? this.players[winnerIdx] : null;
    if (winner) winner.score += 500;
    this.broadcast({
      type: 'game_end',
      reason,
      winner: winner ? { id: winner.id, name: winner.name } : null,
      hands: this.players.map(p => ({ id: p.id, hand: p.hand, melds: p.melds, score: p.score }))
    });
  }

  sendHands() {
    this.players.forEach(p => {
      if (p.ws && p.ws.readyState === 1) {
        p.ws.send(JSON.stringify({ type: 'hand', hand: p.hand, playerIdx: this.players.indexOf(p) }));
      }
    });
  }

  broadcastState() {
    const state = {
      type: 'state',
      phase: this.phase,
      currentTurn: this.currentTurn,
      deckLeft: this.deck.length,
      discard: this.discard,
      players: this.players.map(p => ({
        id: p.id, name: p.name, score: p.score,
        handCount: p.hand.length, melds: p.melds
      }))
    };
    this.broadcast(state);
  }

  broadcast(msg) {
    const str = JSON.stringify(msg);
    this.players.forEach(p => {
      if (p.ws && p.ws.readyState === 1) {
        p.ws.send(str);
      }
    });
  }
}

// ─── WebSocket Handlers ───────────────────────────────────────────────────────
wss.on('connection', (ws) => {
  clients.set(ws, { playerId: null, roomCode: null, name: null });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const ctx = clients.get(ws);

    switch (msg.type) {
      case 'create_room': {
        let code = generateCode();
        while (rooms.has(code)) code = generateCode();
        const room = new MahjongRoom(code, msg.mode, msg.playerId, msg.name);
        room.players[0].ws = ws;
        rooms.set(code, room);
        ctx.playerId = msg.playerId;
        ctx.roomCode = code;
        ctx.name = msg.name;
        ws.send(JSON.stringify({ type: 'room_created', code, mode: msg.mode }));
        break;
      }
      case 'join_room': {
        const room = rooms.get(msg.code);
        if (!room) { ws.send(JSON.stringify({ type: 'error', msg: '房間不存在' })); return; }
        if (room.players.length >= room.maxPlayers) { ws.send(JSON.stringify({ type: 'error', msg: '房間已滿' })); return; }
        if (room.phase !== 'waiting') { ws.send(JSON.stringify({ type: 'error', msg: '遊戲已開始' })); return; }
        room.addPlayer(msg.playerId, msg.name, ws);
        ctx.playerId = msg.playerId;
        ctx.roomCode = msg.code;
        ctx.name = msg.name;
        ws.send(JSON.stringify({ type: 'joined_room', code: msg.code, mode: room.mode }));
        room.broadcast({ type: 'player_joined', name: msg.name, count: room.players.length, max: room.maxPlayers,
          players: room.players.map(p => ({ name: p.name, id: p.id })) });
        break;
      }
      case 'start_game': {
        const room = rooms.get(ctx.roomCode);
        if (!room) return;
        if (room.players[0].id !== ctx.playerId) { ws.send(JSON.stringify({ type: 'error', msg: '只有房主可以開始' })); return; }
        if (room.players.length < 2) { ws.send(JSON.stringify({ type: 'error', msg: '至少需要2位玩家' })); return; }
        room.startGame();
        break;
      }
      case 'discard': {
        const room = rooms.get(ctx.roomCode);
        if (!room || room.phase !== 'playing') return;
        const pidx = room.players.findIndex(p => p.id === ctx.playerId);
        if (pidx !== room.currentTurn) return;
        room.discard_tile(pidx, msg.tile);
        break;
      }
      case 'action': {
        const room = rooms.get(ctx.roomCode);
        if (!room || room.phase !== 'action') return;
        const pidx = room.players.findIndex(p => p.id === ctx.playerId);
        room.handleAction(pidx, msg.action, msg.tiles);
        break;
      }
      case 'restart': {
        const room = rooms.get(ctx.roomCode);
        if (!room || room.players[0].id !== ctx.playerId) return;
        room.phase = 'waiting';
        room.broadcast({ type: 'restart_ready' });
        break;
      }
    }
  });

  ws.on('close', () => {
    const ctx = clients.get(ws);
    if (ctx && ctx.roomCode) {
      const room = rooms.get(ctx.roomCode);
      if (room) {
        room.broadcast({ type: 'player_left', name: ctx.name });
        // Clean up room if empty
        const allGone = room.players.every(p => !p.ws || p.ws.readyState !== 1);
        if (allGone) rooms.delete(ctx.roomCode);
      }
    }
    clients.delete(ws);
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🀄 小麻將伺服器啟動 → http://localhost:${PORT}`);
});
